class Dimens {
  static double subTitleFontSize = 12.0;
  static double itemPadding = 10.0;
  static double dividerHeight = 1.0;
}