import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:money_lover_fake/home/home_cubit.dart';
import 'package:money_lover_fake/models/item.dart';
import 'package:money_lover_fake/widgets/date_picker.dart';

class AddOrEditPage extends StatefulWidget {
  late Item _item;
  late HomeCubit _homeCubit;

  AddOrEditPage(HomeCubit homeCubit, Item index, {Key? key}) : super(key: key) {
    _homeCubit = homeCubit;
    _item = index;
  }

  static Route<void> route(HomeCubit homeCubit, Item _item) {
    return MaterialPageRoute<void>(builder: (_) => AddOrEditPage(homeCubit, _item));
  }

  @override
  State<AddOrEditPage> createState() => _AddOrEditPageState(_homeCubit, _item);
}

class _AddOrEditPageState extends State<AddOrEditPage> {
  late Item _item;
  late HomeCubit _homeCubit;

  final TextEditingController _contentController = TextEditingController();

  String get _content => _contentController.text;

  final TextEditingController _valueController = TextEditingController();

  String get _value => _valueController.text;

  DateTime selectedDate = DateTime.now();

  String _date = "${DateTime.now().toLocal()}".split(' ')[0];

  _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2025),
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
    _date = "${selectedDate.toLocal()}".split(' ')[0];
  }

  _AddOrEditPageState(HomeCubit homeCubit, Item item) {
    _homeCubit = homeCubit;
    _item = item;
  }

  void updateData(bool isIncome) {
    if (_content.isNotEmpty) {
      Navigator.of(context)
          .pop(Item(content: _content, dateTime: _date, value: isIncome ? int.parse(_value) : int.parse("-" + _value)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Add or edit"),
        ),
        body: Center(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                child: TextField(
                  controller: _contentController,
                  decoration: new InputDecoration.collapsed(hintText: 'Content'),
                ),
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text("${selectedDate.toLocal()}".split(' ')[0]),
                  SizedBox(
                    width: 20.0,
                  ),
                  OutlinedButton(
                    onPressed: () => _selectDate(context),
                    child: Text('Select date'),
                  ),
                ],
              ),
              Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                  child: TextField(
                    controller: _valueController,
                    decoration: new InputDecoration.collapsed(
                      hintText: 'value',
                    ),
                    inputFormatters: <TextInputFormatter>[FilteringTextInputFormatter.digitsOnly],
                  )),
              OutlinedButton(
                  onPressed: () {
                    updateData(true);
                  },
                  child: Text("Income")),
              OutlinedButton(
                  onPressed: () {
                    updateData(false);
                  },
                  child: Text("Outcome"))
            ],
          ),
        ));
  }
}
