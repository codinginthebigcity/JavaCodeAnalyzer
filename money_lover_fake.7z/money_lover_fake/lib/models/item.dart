class Item {
  late String _dateTime;
  late int _value;
  late String _content;

  Item({String content = "", String dateTime = "19700101", int value = 0}) {
    _content = content;
    _dateTime = dateTime;
    _value = value;
  }
}
