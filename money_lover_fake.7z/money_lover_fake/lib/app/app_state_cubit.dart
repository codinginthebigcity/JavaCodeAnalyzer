import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:money_lover_fake/models/item.dart';
import 'package:money_lover_fake/repositories/local/local_repository.dart';

part 'app_state_state.dart';

class AppStateCubit extends Cubit<AppScreenState> {
  final LocalRepository _localRepositor;
  late StreamSubscription<int> _localSubscription;

  AppStateCubit(this._localRepositor) : super(AppStateInitial(0)) {
    _localSubscription = _localRepositor.status.listen(
      (event) {
        if (event == 100) {
          emit(AppStateHome());
        } else
          emit(AppStateInitial(event));
      },
    );
  }

  void add() {
  }
}
