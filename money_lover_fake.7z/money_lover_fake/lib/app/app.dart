import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:money_lover_fake/add_or_edit/add_or_edit_page.dart';
import 'package:money_lover_fake/app/app_state_cubit.dart';
import 'package:money_lover_fake/home/home_page.dart';
import 'package:money_lover_fake/repositories/local/local_repository.dart';
import 'package:money_lover_fake/splash/splash_page.dart';

class App extends StatelessWidget {
  const App({
    super.key,
    required this.userRepository,
  });

  final LocalRepository userRepository;

  @override
  Widget build(BuildContext context) {
    return RepositoryProvider.value(
      value: userRepository,
      child: BlocProvider(
        create: (_) => AppStateCubit(userRepository),
        child: const AppView(),
      ),
    );
  }
}

class AppView extends StatefulWidget {
  const AppView({Key? key}) : super(key: key);

  @override
  State<AppView> createState() => _AppViewState();
}

class _AppViewState extends State<AppView> {
  final _navigatorKey = GlobalKey<NavigatorState>();

  NavigatorState get _navigator => _navigatorKey.currentState!;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: _navigatorKey,
      builder: (context, child) {
        return BlocListener<AppStateCubit, AppScreenState>(
          listener: (context, state) {
            if (state is AppStateHome) {
              _navigator.pushAndRemoveUntil<void>(
                HomePage.route(),
                (route) => false,
              );
            }
          },
          child: child,
        );
      },
      onGenerateRoute: (_) => SplashPage.route(),
    );
  }
}
