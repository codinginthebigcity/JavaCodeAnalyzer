part of 'app_state_cubit.dart';

abstract class AppScreenState extends Equatable {
  const AppScreenState();

  @override
  List<Object> get props => [];
}

class AppStateInitial extends AppScreenState {
  int percent = 0;

  AppStateInitial(int percent) {
    this.percent = percent;
  }

  @override
  List<Object> get props => [percent];
}

class AppStateHome extends AppScreenState {}

