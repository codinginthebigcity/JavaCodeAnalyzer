import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:money_lover_fake/add_or_edit/add_or_edit_page.dart';
import 'package:money_lover_fake/app/app_state_cubit.dart';
import 'package:money_lover_fake/home/home_cubit.dart';
import 'package:money_lover_fake/models/item.dart';
import 'package:money_lover_fake/values/dimens.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  static Route<void> route() {
    return MaterialPageRoute<void>(builder: (_) => const HomePage());
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => HomeCubit(),
      child: HomePageView(),
    );
  }
}

class HomePageView extends StatefulWidget {
  const HomePageView({Key? key}) : super(key: key);

  @override
  State<HomePageView> createState() => _HomePageViewState();
}

class _HomePageViewState extends State<HomePageView> {
  @override
  Widget build(BuildContext context) {
    return Material(
        child: Scaffold(
      appBar: AppBar(title: const Text("Money lover")),
      body: ListView.separated(
        itemCount: 10,
        itemBuilder: (context, index) {
          return Padding(
              padding: new EdgeInsets.all(Dimens.itemPadding),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Main text"),
                      Text("Sub text", style: TextStyle(fontSize: Dimens.subTitleFontSize))
                    ],
                  ),
                  Spacer(flex: 1),
                  IconButton(
                      onPressed: () {
                        print("Edited " + index.toString());
                      },
                      icon: Icon(Icons.edit)),
                  IconButton(
                      onPressed: () {
                        context.read<HomeCubit>().remove(1);
                      },
                      icon: Icon(Icons.remove))
                ],
              ));
        },
        separatorBuilder: (BuildContext context, int index) => Divider(height: Dimens.dividerHeight),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () {
            print("added");
            Navigator.of(context).push<void>(
              AddOrEditPage.route(context.read<HomeCubit>(), Item(content: "", dateTime: "", value: -1)),
            );
          },
          child: Icon(Icons.add)),
    ));
  }
}
