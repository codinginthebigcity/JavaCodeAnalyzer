
import 'dart:async';
import 'dart:convert';

import 'package:money_lover_fake/models/item.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LocalRepository{

  final _controller = StreamController<int>();

  Stream<int> get status async* {
    await Future<void>.delayed(const Duration(seconds: 1));
    yield 50;
    await Future<void>.delayed(const Duration(seconds: 1));
    yield 90;
    await Future<void>.delayed(const Duration(milliseconds: 333));
    yield 100;
    yield* _controller.stream;
  }

  void dispose() => _controller.close();

  Future<void> saveData(List<Item> data) async {

    List<String> favorites = [];

    // Generate json for each restaurant
    for(var resto in data) {
      var json = jsonEncode(resto);
      favorites.add(json);
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('items', favorites);
  }
}