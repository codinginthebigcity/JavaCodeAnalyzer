import 'package:bloc/bloc.dart';
import 'package:flutter/widgets.dart';
import 'package:money_lover_fake/app/app_bloc_observer.dart';

import 'app/app.dart';
import 'repositories/local/local_repository.dart';

void main() {
  Bloc.observer = AppBlocObserver();
  runApp(
    App(
      userRepository: LocalRepository(),
    ),
  );
}
