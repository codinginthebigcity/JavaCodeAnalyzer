package com.example.money_lover_fake

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
